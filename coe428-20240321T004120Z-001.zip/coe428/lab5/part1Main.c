#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

extern int pop();
extern void push(int);
extern int isEmpty();

int main(int argc, char *argv[]) {
    int ch, chpop;

    while ((ch = getchar()) != EOF) {
        if (!(isalpha(ch) || ch == '>' || ch == '<' || ch == '/')) {
            continue;
        }
        
         else if (ch == '<') {
            ch = getchar();
            if (isalpha(ch)) {

                if (getchar() == '>') {
                    push(ch);
                } 
                
                else {
                    fprintf(stderr, "Invalid\n");
                    exit(1);
                }
            } 
            
            else if (ch == '/') {
                ch = getchar();

                if (isalpha(ch)) {
                    if (getchar() == '>') {

                        if (isEmpty()) {
                            fprintf(stderr, "Invalid\n");
                            exit(1);
                        } 
                        
                        else if ((chpop = pop()) == ch) {
                            continue;
                        } 
                        
                        else {
                            fprintf(stderr, "Invalid\n");
                            exit(1);
                        }
                    } 
                    
                    else {
                        fprintf(stderr, "Invalid\n");
                        exit(1);
                    }
                }
            }
        } 
        else {
            continue;
        }
    }

    if (isEmpty()) {
        printf("Valid\n");
        exit(0);
    } 
    
    else {
        printf("Invalid\n");
        exit(1);
    }
}
