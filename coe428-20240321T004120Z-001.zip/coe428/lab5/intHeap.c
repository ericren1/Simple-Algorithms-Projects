/**
 *  The functions in this module implement a Heapdata structure
 *  of integers.
 */

#include <stdio.h>
#include <stdlib.h>

static int heap[100];
static int size = 1;


void heapify(int);

/**
 * heapDelete() removes the biggest integer in the heap and returns it.
 *
 */

int heapDelete()
{
  int max = heap[1];
  size--;
  heap[1] = heap[size];
  heapify(1);
  return max;
}

/**
 *  addHeap(thing2add) adds the "thing2add" to the Heap.
 *
 */
void addHeap(int thing2add)
{
  if (size > 100) {
    fprintf(stderr, "Cannot add to a full heap.\n");
    return;
  }
  heap[size] = thing2add;
  int i = size;
  int temp = i/2;
  while (temp > 0 && heap[temp] < thing2add) {
    heap[i] = heap[temp];
    heap[temp] = thing2add; 
    i = temp;
    temp = i/2;
  }
  size++;
}

/**
 * heapSize() returns the number of items in the Heap.
 *
 */
int heapSize()
{
  return size;
}

void heapify(int i) {
  int temp;
  int largest;
  int left = 2 * i;
  int right = 2 * i + 1;

  if (left <= heapSize() && heap[i] < heap[left]) {
    largest = left;
  } else {
    largest = i;
  }
  if (right <= heapSize() && heap[largest] < heap[right]) {
    largest = right;
  }

  if (largest != i) {
    temp = heap[i];
    heap[i] = heap[largest];
    heap[largest] = temp;
    heapify(largest);
  }
}

void printHeap(int position) {
  int next_position;
  printf("<node id=\"%d\">", heap[position]);
  next_position = position * 2;
  if (next_position <= heapSize()) {
    printHeap(next_position);
  }

  next_position = position * 2 + 1;
  if (next_position <= heapSize()) {
    printHeap(next_position);
  }
  
  if (next_position > heapSize() && next_position/2 <= heapSize()) {
    printf("</node>");
  }
}

void buildMaxHeap() {
  int j;
  for (j = heapSize() / 2; j >= 1; j--) {
    heapify(j);
  }
}