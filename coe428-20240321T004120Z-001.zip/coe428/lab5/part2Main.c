#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

extern int pop();
extern void push(int);
extern int isEmpty();

extern void addHeap(int);
extern int heapDelete();
extern int heapSize();

extern void printHeap(int);
extern void buildMaxHeap();

int main(int argc, char * argv[]) {
  int value, temp;
  while (scanf("%d", & value) != EOF) {
    addHeap(value);
  }
  buildMaxHeap();
  printHeap(1);
  printf("\n");
  printf("\nDescending:\n");
  while (heapSize() > 1) {
    temp = heapDelete();
    printf("%d\n", temp);
    push(temp);
  }
  printf("Ascending:\n");
  while (isEmpty() != 1) {
    printf("%d\n", pop());
  }
  printf("\n");
  exit(0);
}
