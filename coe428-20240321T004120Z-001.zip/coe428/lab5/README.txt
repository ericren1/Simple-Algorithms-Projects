This lab contained two parts with several classes each to be implemented

part 1:
first is the stringStack class which used a fixed array of 100 string elements and implements three functions, pop,push and isEmpty. the pop function removes the top string on the stack and
then returns that string by making a pointer that points to the top of the stack and decreasing the value of the top so the pointer will then point to the next item.
push function adds the parameter to the top of the stack by making the parameter and top item of the stack the same value.
isEmpty function returns 2 when there is nothing in the stack and 0 if else

For part 2:
the intStack class is similar to the stringStack class in part 1 however inStack can accept  integer inputs instead of just string input.
the intHeap class has three methods used to modify the heap, heapDelete removes the largest int by storing the max int in the heap for later to se as a return, it then will modify the heap by comparing 
root nodes with children and swapping the root node with the largest child nodes to make sure the root node is always the largest element withing the heap.
addHeap adds the parameter to the heap, it does this by swapping  and comparing the parameter with parent int. if the parent is smaller a swap is performed between the two
heapSize returns the number of elements in the heap
other methods used were heapify printHeap and buildmaxHeap which help to print the heap
heapify helps the array to follow an xml tree. comparing the parameter index values with the left and right child then swapping the parent node with the largest child and then calling itself recursively on the swapped child node.
printHeap prints the heap in a binary tree with xml formatting by making the heap in a depth first order from the root node or index 1 and printing each nodes value in html
buildmaxHeap creats a max heap starting from the middle of the array and applying heapify method to each element 

the part2Main class uses the intHeap and intStack class to accept user input to print it as a xml binary tree and then it sorts the input in descending order and prints it in descending and ascending order


Another legal XML tag not used in this lab is the "stand-alone" tag. This kind of tag combines both a start-tag and end-tag in one. It is identified with a '/' (slash) preceding the final >. (For example, the <foo/> is a stand-alone tag 
that is "self balancing"). 

Describe briefly how you would modify Requirement 1 to allow this kind of tag.?

I would modify the code from Requirement 1 and make it check if the tag is stand alone by looking for / before the final > character.