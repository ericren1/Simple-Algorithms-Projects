#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

static int top = 0;
static int stack[100];

int isEmpty();

/**
 * pop() removes the top integer on the stack and returns it.
 *
 * If pop() is attempted on an empty stack, an error message
 * is printed to stderr and the value -1 (minus one) is returned.
 */

int pop()
{
  if (isEmpty() == 1) {
    fprintf(stderr, "Cannot pop from an empty stack.\n");
    return -1;
  }

  else{
    int top_int = stack[top];
    top--;
    return top_int;
  }
}

/**
 *  push(thing2push) adds the "thing2push" to the top of the stack.
 *
 *  If there is no more space available on the Stack, an error
 *  message is printed to stderr.
 */
void push(int thing2push)
{
  if (top == 100) {
    fprintf(stderr, "Cannot push onto a full stack.\n");
    return;
  }

  else{
    top++;
    stack[top] = thing2push;
  }
}

/**
 * isEmpty() returns a non-zero integer (not necessarily 1) if the
 * stack is empty; otherwise, it returns 0 (zero).
 *
 */
int isEmpty()
{
  if (top == 0) {
    return 1;
  }

  else {
    return 0;
  }
}


/**
 *  The functions in this module implement a Heapdata structure
 *  of integers.
 */

static int heap[100];
static int size = 1;

void heapify(int);

/**
 * heapDelete() removes the biggest integer in the heap and returns it.
 *
 */

int heapDelete()
{
  int max = heap[1];
  size--;
  heap[1] = heap[size];
  heapify(1);
  return max;
}

/**
 *  addHeap(thing2add) adds the "thing2add" to the Heap.
 *
 */
void addHeap(int thing2add)
{
  if (size > 100) {
    fprintf(stderr, "Cannot add to a full heap.\n");
    return;
  }
  heap[size] = thing2add;
  int i = size;
  int temp = i/2;
  while (temp > 0 && heap[temp] < thing2add) {
    heap[i] = heap[temp];
    heap[temp] = thing2add; 
    i = temp;
    temp = i/2;
  }
  size++;
}

/**
 * heapSize() returns the number of items in the Heap.
 *
 */
int heapSize()
{
  return size;
}

void heapify(int i) {
  int temp;
  int largest;
  int left = 2 * i;
  int right = 2 * i + 1;

  if (left <= heapSize() && heap[i] < heap[left]) {
    largest = left;
  } else {
    largest = i;
  }
  if (right <= heapSize() && heap[largest] < heap[right]) {
    largest = right;
  }

  if (largest != i) {
    temp = heap[i];
    heap[i] = heap[largest];
    heap[largest] = temp;
    heapify(largest);
  }
}

void printHeap(int position) {
  int next_position;
  printf("<node id=\"%d\">", heap[position]);
  next_position = position * 2;
  if (next_position <= heapSize()) {
    printHeap(next_position);
  }

  next_position = position * 2 + 1;
  if (next_position <= heapSize()) {
    printHeap(next_position);
  }
  printf("<\\node>");
}

void buildMaxHeap() {
  int j;
  for (j = heapSize() / 2; j >= 1; j--) {
    heapify(j);
  }
}

int main(int argc, char * argv[]) {
  int value, temp;
  while (scanf("%d", & value) != EOF) {
    addHeap(value);
  }
  buildMaxHeap();
  printHeap(1);
  printf("\n");
  printf("\nDescending:\n");
  while (heapSize() > 1) {
    temp = heapDelete();
    printf("%d\n", temp);
    push(temp);
  }
  printf("Ascending:\n");
  while (isEmpty() != 1) {
    printf("%d\n", pop());
  }
  printf("\n");
  exit(0);
}