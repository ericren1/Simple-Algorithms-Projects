#include "mySort.h"

void mySort(int array[], unsigned int first, unsigned int last)
    {
	//declaring placeholder variables for first last and temp
        int a,b,temp;
	//loop that runs from first to last element
        for (a  = first; a  <= last; a++) {
            temp = array[a];
            b = a - 1;

	//while b is greater then or equal to zero and index b of array is => then temp
            while (b >= 0 && (myCompare(array[b], temp) >0)) {
		//swapping index b with the next index of the array
                mySwap(&array[b+1], &array[b]);
                b = b - 1;
            }
	//replacing index at array b+1 with temp
             myCopy(&temp,&array[b+1]);
        }
    }
