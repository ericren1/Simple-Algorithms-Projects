void mySort(int d[], unsigned int n)
{

	int i,temp;
	for (i = 0;i<n-1;i++){
		if (d[i] > d[i+1]){		
			temp = d[i];
			d[i] = d[i+1];
			d[i+1] = temp;
		}
	}
}
