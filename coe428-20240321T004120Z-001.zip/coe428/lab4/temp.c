#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

int main(int argc, char * argv[])
{
    char stateMachine[][3] = {
        {'A', 'G', 'D'}, 
        {'B', 'C', 'G'}, 
        {'C', 'A', 'H'}, 
        {'D', 'F', 'A'}, 
        {'E', 'H', 'B'}, 
        {'F', 'E', 'F'}, 
        {'G', 'C', 'F'}, 
        {'H', 'D', 'B'}
    };
    char startState = stateMachine[5][0];
    char currentState = startState;
    char garbageBin[20] = "";
    char input[5];
    char nextState;
    int rows = 8, columns = 3, i, j, n;
    bool flag = false, garbage = false;

//starting state
    printf("Starting State is: %c\n", startState);

//scainning for input
    while (scanf("%5[^\n]%*c", input) == 1) {

//change current state
        if (input[0] == '0') {
            for (i = 0; i < rows; i++) {
                if (stateMachine[i][0] == currentState) {
                    nextState = stateMachine[i][1];
                    printf("New State: %c\n\n", nextState);
                    currentState = nextState;
                    break;
                }
            }
        }
        else if (input[0] == '1') {
            for (i = 0; i < rows; i++) {
                if (stateMachine[i][0] == currentState) {
                    nextState = stateMachine[i][2];
                    printf("New State: %c\n\n", nextState);
                    currentState = nextState;
                    break;
                }
            }
        }
//change state transisiton 
        else if (input[0] == 'c'){
            if (input[2] == '0'){
                for (i = 0; i < rows; i++) {
                    if (stateMachine[i][0] == currentState) {
                        stateMachine[i][1] = input[4];
                        break;
                    }
                }
            }

            if (input[2] == '1'){
                for (i = 0; i < rows; i++) {
                    if (stateMachine[i][0] == currentState) {
                        stateMachine[i][2] = input[4];
                        break; 
                    }
                }
            }
        }
//print out array
        else if (input[0] == 'p'){
            for (i = 0; i < rows; i++) {
                for (j = 0; j < columns; j++) {
                    printf("%c ", stateMachine[i][j]);
                }
                printf("\n");
            }
        printf("\n");
        }

//checking for unreachable states
        else if (input[0] == 'g'){
            for (n = 0; n < rows; n++) {
                flag = false;
                for (i = 0; i < rows && flag == false; i++) {
                    for (j = 1; j < columns && flag == false; j++) {
                        if (i == (rows - 1) && j == (columns - 1)) {
                            garbage = true;
                            char tempStr[2] = {stateMachine[n][0], '\0'};
                            strcat(garbageBin, tempStr);
                            printf("garbage: %c\n\n", stateMachine[n][0]);
                        }
                        if (stateMachine[n][0] == stateMachine[i][j]) {
                            flag = true;
                        }
                    }         
                }
            }

            if (garbage != true){
                printf("No Garbage\n");
            }
            
        }

//deleteing specfied or garbage states
        else if (input[0] == 'd'){
            if (input[1] == '\0'){
                if (garbageBin[0] != '\0'){
                    for (i = 0; i < rows; i++) {
                        for (int k = 0; k < rows; k++){
                            if (stateMachine[i][0] == garbageBin[k]) {
                                for (n = i; n < rows - 1; n++) {
                                    for (j = 0; j < columns; j++) {
                                        stateMachine[n][j] = stateMachine[n+1][j];
                                    }   
                                }
                            rows--;
                            i--;
                            }
                        }
                    }
                    printf("States Deleted: %s\n\n", garbageBin);
                }
                
                else if (garbageBin[0] == '\0'){
                    printf("No States Deleted\n\n");
                }
                
            }
          
            else if (input[1] != '\0'){
                bool found = false;
                for (i = 0; i < rows; i++) {
                    if (stateMachine[i][0] == input[2]) {
                        for (n = i; n < rows - 1; n++) {
                            for (j = 0; j < columns; j++) {
                                        stateMachine[n][j] = stateMachine[n+1][j];
                            }   
                        }
                    found = true;
                    rows--;
                    i--;
                    }           
                }
                if (found == true){
                    printf("Deleted\n\n");
                }

                else if (found == false){
                    printf("Not Deleted\n\n");
                }
            }
        }
    }

    exit(0);
}
